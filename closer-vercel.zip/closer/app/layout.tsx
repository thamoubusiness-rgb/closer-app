import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "Closer — Your AI Sales Employee for Real Estate",
  description:
    "Closer responds to real-estate leads, qualifies prospects, recommends properties and books viewings automatically.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "Inter, system-ui, sans-serif", colorScheme: "light dark" }}>
        {children}
      </body>
    </html>
  );
}
