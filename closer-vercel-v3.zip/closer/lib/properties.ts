import { z } from "zod";

export const STATUSES = ["available", "reserved", "sold", "unavailable"] as const;
export const MAX_ROWS = 500;
export const TEMPLATE_HEADER =
  "title,description,price,currency,location,address,property_type,bedrooms,bathrooms,area_sqm,availability_status,url";

const blank = (v: unknown) => (typeof v === "string" && v.trim() === "" ? undefined : v);
const text = (max: number) => z.preprocess(blank, z.string().trim().max(max).optional());
const num = (max: number) => z.preprocess(blank, z.coerce.number().min(0).max(max).optional());
const int = (max: number) => z.preprocess(blank, z.coerce.number().int().min(0).max(max).optional());
export const HTTP_URL = /^https?:\/\/\S+$/i; // blocks javascript: and other schemes

export const propertySchema = z.object({
  title: z.string().trim().min(2, "required").max(200),
  description: text(5000),
  price: num(1e10),
  currency: z.preprocess(blank, z.string().trim().toUpperCase().length(3, "use a 3-letter code").default("EUR")),
  location: text(200),
  address: text(300),
  property_type: text(50),
  bedrooms: int(20),
  bathrooms: num(20),
  area_sqm: num(100000),
  availability_status: z.preprocess(blank, z.enum(STATUSES).default("available")),
  url: z.preprocess(blank, z.string().max(500).regex(HTTP_URL, "must start with http:// or https://").optional()),
});
export type PropertyInput = z.infer<typeof propertySchema>;

/** Empty optional fields are stored as null so editing can clear a value. */
export function toRow(p: PropertyInput) {
  return Object.fromEntries(Object.entries(p).map(([k, v]) => [k, v ?? null]));
}

/** One URL per line, max 10. Returns null if any line is not a valid http(s) URL. */
export function parsePhotos(input: string): string[] | null {
  const urls = input.split(/\s+/).filter(Boolean);
  return urls.length <= 10 && urls.every((u) => HTTP_URL.test(u)) ? urls : null;
}

export function money(price: number | null, currency: string): string {
  if (price === null) return "–";
  try {
    return new Intl.NumberFormat("en-GB", { style: "currency", currency, maximumFractionDigits: 0 }).format(price);
  } catch {
    return `${currency} ${price.toLocaleString("en-GB")}`;
  }
}

/** Minimal RFC 4180 parser. Auto-detects ; (common in Italian Excel exports) or , as the delimiter. */
export function parseCsv(input: string): string[][] {
  const text = input.replace(/^\uFEFF/, "");
  const first = text.split(/\r?\n/, 1)[0] ?? "";
  const d = (first.match(/;/g)?.length ?? 0) > (first.match(/,/g)?.length ?? 0) ? ";" : ",";
  const rows: string[][] = [];
  let row: string[] = [], cell = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else quoted = false; }
      else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === d) { row.push(cell); cell = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cell); rows.push(row); row = []; cell = "";
    } else cell += c;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

export interface RowResult { line: number; title: string; data?: PropertyInput; errors: string[] }
export interface Validation { rows: RowResult[]; error?: string }

export function validateRows(table: string[][]): Validation {
  if (table.length < 2) return { rows: [], error: "The file has no data rows." };
  const header = table[0].map((h) => h.trim().toLowerCase());
  if (!header.includes("title")) return { rows: [], error: "The file needs a “title” column." };
  if (table.length - 1 > MAX_ROWS) return { rows: [], error: `Too many rows. The limit is ${MAX_ROWS} per import.` };
  const rows = table.slice(1).map((cells, i): RowResult => {
    const obj: Record<string, string> = {};
    header.forEach((h, idx) => { obj[h] = (cells[idx] ?? "").trim(); });
    const parsed = propertySchema.safeParse(obj);
    return parsed.success
      ? { line: i + 2, title: obj.title, data: parsed.data, errors: [] }
      : { line: i + 2, title: obj.title, errors: parsed.error.issues.map((x) => `${x.path.join(".") || "row"}: ${x.message}`) };
  });
  return { rows };
}
