import { describe, expect, it } from "vitest";
import { parseCsv, parsePhotos, propertySchema, validateRows } from "./properties";

describe("properties", () => {
  it("parses quoted commas, escaped quotes, BOM and semicolon files", () => {
    expect(parseCsv('\uFEFFtitle,price\n"Bright 2-bed, Brera",445000\n"He said ""hi""",1')).toEqual([
      ["title", "price"], ["Bright 2-bed, Brera", "445000"], ['He said "hi"', "1"],
    ]);
    expect(parseCsv("title;price\nFlat;100")).toEqual([["title", "price"], ["Flat", "100"]]);
  });

  it("treats blanks as missing and applies defaults", () => {
    const p = propertySchema.parse({ title: "Flat", price: "", currency: "", availability_status: "" });
    expect(p.price).toBeUndefined();
    expect(p.currency).toBe("EUR");
    expect(p.availability_status).toBe("available");
  });

  it("rejects bad numbers, statuses and unsafe URLs", () => {
    expect(propertySchema.safeParse({ title: "Flat", price: "abc" }).success).toBe(false);
    expect(propertySchema.safeParse({ title: "Flat", availability_status: "maybe" }).success).toBe(false);
    expect(propertySchema.safeParse({ title: "Flat", url: "javascript:alert(1)" }).success).toBe(false);
    expect(parsePhotos("https://a.com/1.jpg\nhttps://a.com/2.jpg")).toHaveLength(2);
    expect(parsePhotos("data:text/html;base64,xx")).toBeNull();
  });

  it("flags invalid CSV rows instead of importing them", () => {
    const v = validateRows(parseCsv("title,price,bedrooms\nGood flat,300000,2\n,100,1\nBad price,lots,2"));
    expect(v.rows.map((r) => Boolean(r.data))).toEqual([true, false, false]);
    expect(v.rows[2].errors[0]).toContain("price");
    expect(validateRows(parseCsv("name,price\nx,1")).error).toContain("title");
  });
});
