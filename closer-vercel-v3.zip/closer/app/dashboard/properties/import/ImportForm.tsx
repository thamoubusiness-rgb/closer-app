"use client";

import { useActionState, useState, type ChangeEvent } from "react";
import { TEMPLATE_HEADER, parseCsv, validateRows, type Validation } from "@/lib/properties";
import { importProperties, type FormState } from "../actions";

export default function ImportForm() {
  const [result, setResult] = useState<Validation | null>(null);
  const [state, action, pending] = useActionState<FormState, FormData>(importProperties, undefined);

  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_000_000) return setResult({ rows: [], error: "The file is larger than 1 MB." });
    setResult(validateRows(parseCsv(await file.text())));
  }
  const valid = result?.rows.filter((r) => r.data) ?? [];
  const invalid = (result?.rows.length ?? 0) - valid.length;

  return (
    <>
      <p className="mut">
        Columns: <code>{TEMPLATE_HEADER}</code>. Only <code>title</code> is required. Use plain numbers (450000, not 450.000,00).{" "}
        <a style={{ textDecoration: "underline" }} download="closer-properties-template.csv"
          href={`data:text/csv;charset=utf-8,${encodeURIComponent(TEMPLATE_HEADER + "\n")}`}>Download template</a>
      </p>
      <label className="field" style={{ maxWidth: 420 }}>CSV file
        <input type="file" accept=".csv,text/csv" onChange={onFile} />
      </label>
      {result?.error && <p className="err" role="alert">{result.error}</p>}
      {result && !result.error && (
        <>
          <p role="status"><strong>{valid.length}</strong> valid, <strong className={invalid ? "bad" : ""}>{invalid}</strong> with errors. Rows with errors will be skipped.</p>
          <div className="box tbl" style={{ marginBottom: 16 }}>
            <table>
              <thead><tr><th>Line</th><th>Title</th><th>Result</th></tr></thead>
              <tbody>{result.rows.map((r) => (
                <tr key={r.line}><td>{r.line}</td><td>{r.title || "–"}</td>
                  <td className={r.data ? "ok" : "bad"}>{r.data ? "Ready" : r.errors.join("; ")}</td></tr>
              ))}</tbody>
            </table>
          </div>
          <form action={action}>
            <input type="hidden" name="rows" value={JSON.stringify(valid.map((r) => r.data))} />
            {state?.error && <p className="err" role="alert">{state.error}</p>}
            <button className="btn" type="submit" disabled={pending || valid.length === 0}>
              {pending ? "Importing…" : `Import ${valid.length} ${valid.length === 1 ? "property" : "properties"}`}
            </button>
          </form>
        </>
      )}
    </>
  );
}
