import ImportForm from "./ImportForm";

export const metadata = { title: "Import properties — Closer" };

export default function Page() {
  return (
    <>
      <h1 style={{ marginBottom: 12 }}>Upload CSV</h1>
      <ImportForm />
    </>
  );
}
