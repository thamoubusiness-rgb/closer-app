import PropertyForm from "../PropertyForm";
import { saveProperty } from "../actions";

export const metadata = { title: "Add property — Closer" };

export default function Page() {
  return (
    <>
      <h1 style={{ marginBottom: 20 }}>Add property</h1>
      <PropertyForm action={saveProperty.bind(null, null)} />
    </>
  );
}
