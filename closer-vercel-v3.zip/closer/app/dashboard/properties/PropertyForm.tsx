"use client";

import { useActionState } from "react";
import { STATUSES } from "@/lib/properties";
import type { FormState } from "./actions";

export interface Defaults {
  title?: string; description?: string | null; price?: number | null; currency?: string; location?: string | null;
  address?: string | null; property_type?: string | null; bedrooms?: number | null; bathrooms?: number | null;
  area_sqm?: number | null; availability_status?: string; url?: string | null; photos?: string[] | null;
}

export default function PropertyForm({ action, defaults = {} }: {
  action: (prev: FormState, form: FormData) => Promise<FormState>; defaults?: Defaults;
}) {
  const [state, run, pending] = useActionState<FormState, FormData>(action, undefined);
  const v = (x: string | number | null | undefined) => x ?? "";
  return (
    <form action={run} className="form" noValidate>
      <label className="field full">Title<input name="title" defaultValue={v(defaults.title)} required /></label>
      <label className="field full">Description<textarea name="description" rows={4} defaultValue={v(defaults.description)} /></label>
      <label className="field">Price<input name="price" type="number" min="0" step="any" defaultValue={v(defaults.price)} /></label>
      <label className="field">Currency<input name="currency" maxLength={3} defaultValue={v(defaults.currency ?? "EUR")} /></label>
      <label className="field">Location (city or area)<input name="location" defaultValue={v(defaults.location)} /></label>
      <label className="field">Address<input name="address" defaultValue={v(defaults.address)} /></label>
      <label className="field">Property type<input name="property_type" placeholder="apartment, house…" defaultValue={v(defaults.property_type)} /></label>
      <label className="field">Bedrooms<input name="bedrooms" type="number" min="0" defaultValue={v(defaults.bedrooms)} /></label>
      <label className="field">Bathrooms<input name="bathrooms" type="number" min="0" step="0.5" defaultValue={v(defaults.bathrooms)} /></label>
      <label className="field">Area (m²)<input name="area_sqm" type="number" min="0" step="any" defaultValue={v(defaults.area_sqm)} /></label>
      <label className="field">Availability
        <select name="availability_status" defaultValue={defaults.availability_status ?? "available"}>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </label>
      <label className="field">Listing URL<input name="url" type="url" placeholder="https://" defaultValue={v(defaults.url)} /></label>
      <label className="field full">Photo URLs (one per line)<textarea name="photos" rows={3} defaultValue={(defaults.photos ?? []).join("\n")} /></label>
      <div className="full">
        {state?.error && <p className="err" role="alert">{state.error}</p>}
        <button className="btn" type="submit" disabled={pending}>{pending ? "Saving…" : "Save property"}</button>
      </div>
    </form>
  );
}
