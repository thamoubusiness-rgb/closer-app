import { notFound } from "next/navigation";
import { z } from "zod";
import { requireOrg } from "@/lib/auth";
import PropertyForm, { type Defaults } from "../PropertyForm";
import { saveProperty } from "../actions";

export const metadata = { title: "Edit property — Closer" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = z.string().uuid().safeParse((await params).id);
  if (!id.success) notFound();
  const { supabase, org } = await requireOrg();
  const { data } = await supabase.from("properties").select("*")
    .eq("id", id.data).eq("organization_id", org.id).maybeSingle();
  if (!data) notFound();
  return (
    <>
      <h1 style={{ marginBottom: 20 }}>Edit property</h1>
      <PropertyForm action={saveProperty.bind(null, id.data)} defaults={data as Defaults} />
    </>
  );
}
