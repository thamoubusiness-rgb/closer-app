"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireOrg } from "@/lib/auth";
import { MAX_ROWS, parsePhotos, propertySchema, toRow } from "@/lib/properties";

export type FormState = { error?: string } | undefined;

// The organization always comes from the session (requireOrg), and every write is also scoped by organization_id.
export async function saveProperty(id: string | null, _: FormState, form: FormData): Promise<FormState> {
  const parsed = propertySchema.safeParse(Object.fromEntries(form));
  if (!parsed.success) {
    const i = parsed.error.issues[0];
    return { error: `${i.path.join(".") || "Form"}: ${i.message}` };
  }
  const photos = parsePhotos(String(form.get("photos") ?? ""));
  if (!photos) return { error: "Photo URLs must start with http:// or https:// (one per line, max 10)." };

  const { supabase, org } = await requireOrg();
  const row = { ...toRow(parsed.data), photos };
  const { error } = id
    ? await supabase.from("properties").update(row).eq("id", id).eq("organization_id", org.id)
    : await supabase.from("properties").insert({ ...row, organization_id: org.id });
  if (error) return { error: "Could not save the property. Please try again." };
  revalidatePath("/dashboard/properties");
  redirect("/dashboard/properties");
}

export async function deleteProperty(form: FormData): Promise<void> {
  const id = z.string().uuid().safeParse(form.get("id"));
  if (!id.success) return;
  const { supabase, org } = await requireOrg();
  await supabase.from("properties").delete().eq("id", id.data).eq("organization_id", org.id);
  revalidatePath("/dashboard/properties");
  redirect("/dashboard/properties");
}

// Rows are validated again here: never trust what the browser previewed.
export async function importProperties(_: FormState, form: FormData): Promise<FormState> {
  let raw: unknown;
  try { raw = JSON.parse(String(form.get("rows") ?? "[]")); } catch { return { error: "Invalid import data." }; }
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > MAX_ROWS) {
    return { error: `Nothing to import (max ${MAX_ROWS} rows).` };
  }
  const rows = [];
  for (const r of raw) {
    const p = propertySchema.safeParse(r);
    if (!p.success) return { error: "Some rows are invalid. Upload the file again." };
    rows.push(p.data);
  }
  const { supabase, org } = await requireOrg();
  const { error } = await supabase.from("properties").insert(
    rows.map((r) => ({ ...toRow(r), photos: [], organization_id: org.id, import_source: "csv" })),
  );
  if (error) return { error: "Could not import the properties. Please try again." };
  revalidatePath("/dashboard/properties");
  redirect(`/dashboard/properties?imported=${rows.length}`);
}
