import Link from "next/link";
import { requireOrg } from "@/lib/auth";
import { HTTP_URL, money } from "@/lib/properties";
import { deleteProperty } from "./actions";

export const metadata = { title: "Properties — Closer" };

interface Row {
  id: string; title: string; price: number | null; currency: string; location: string | null; bedrooms: number | null;
  bathrooms: number | null; area_sqm: number | null; availability_status: string; approved: boolean; photos: string[] | null;
}

export default async function Page({ searchParams }: { searchParams: Promise<{ imported?: string }> }) {
  const { imported } = await searchParams;
  const { supabase, org } = await requireOrg();
  const { data } = await supabase.from("properties")
    .select("id,title,price,currency,location,bedrooms,bathrooms,area_sqm,availability_status,approved,photos")
    .eq("organization_id", org.id).order("created_at", { ascending: false }).limit(200);
  const rows = (data ?? []) as Row[];

  return (
    <>
      <div className="head">
        <h1 style={{ margin: 0 }}>Properties</h1>
        <div className="acts">
          <Link className="btn s" href="/dashboard/properties/import">Upload CSV</Link>
          <Link className="btn" href="/dashboard/properties/new">Add property</Link>
        </div>
      </div>
      {imported && <p className="ok" role="status">Imported {Number(imported) || 0} properties.</p>}
      {rows.length === 0 ? (
        <div className="box empty">
          <p><strong>No properties yet.</strong></p>
          <p className="mut">Closer only recommends properties you add here.</p>
          <div className="acts" style={{ justifyContent: "center", display: "flex", gap: 8 }}>
            <Link className="btn s" href="/dashboard/properties/import">Upload CSV</Link>
            <Link className="btn" href="/dashboard/properties/new">Add property</Link>
          </div>
        </div>
      ) : (
        <div className="box tbl">
          <table>
            <thead><tr><th></th><th>Title</th><th>Price</th><th>Location</th><th>Bd</th><th>Ba</th><th>m²</th><th>Status</th><th></th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.id}>
                <td>{r.photos?.[0] && HTTP_URL.test(r.photos[0]) ? <img className="thumb" src={r.photos[0]} alt="" loading="lazy" /> : null}</td>
                <td>{r.title}</td><td>{money(r.price, r.currency)}</td><td>{r.location ?? "–"}</td>
                <td>{r.bedrooms ?? "–"}</td><td>{r.bathrooms ?? "–"}</td><td>{r.area_sqm ?? "–"}</td>
                <td><span className="badge">{r.availability_status}</span>{!r.approved && <> <span className="badge">needs review</span></>}</td>
                <td>
                  <Link href={`/dashboard/properties/${r.id}`} style={{ textDecoration: "underline" }}>Edit</Link>
                  <details className="del">
                    <summary>Delete</summary>
                    <form action={deleteProperty}>
                      <input type="hidden" name="id" value={r.id} />
                      <button className="btn s sm" type="submit" style={{ marginTop: 6 }}>Confirm delete</button>
                    </form>
                  </details>
                </td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </>
  );
}
